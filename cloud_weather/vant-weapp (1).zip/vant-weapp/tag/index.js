import { VantComponent } from '../common/component';
VantComponent({
  props: {
    type: String,
    mark: Boolean,
    plain: Boolean
  }
});